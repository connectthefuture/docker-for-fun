logrotate
=========

Logrotate is used to rotate logs. Currently, the rotation interval is set to
rotate daily for 7 days. The following components are rotated:

- :doc:`docker`
- :doc:`mesos`
- :doc:`zookeeper`
