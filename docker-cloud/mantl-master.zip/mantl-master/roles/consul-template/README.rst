consul-template
===============

The consul-template role makes sure a good version of `consul-template
<https://github.com/hashicorp/consul-template>`_ is present on the system for
templating tasks.
