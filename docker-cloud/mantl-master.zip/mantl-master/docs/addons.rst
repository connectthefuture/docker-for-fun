.. include:: ../addons/README.rst
