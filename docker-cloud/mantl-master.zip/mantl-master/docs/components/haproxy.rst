.. include:: ../../roles/haproxy/README.rst
