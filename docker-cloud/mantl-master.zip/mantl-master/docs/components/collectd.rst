.. include:: ../../roles/collectd/README.rst
