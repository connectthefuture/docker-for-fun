.. include:: ../../roles/consul-template/README.rst
