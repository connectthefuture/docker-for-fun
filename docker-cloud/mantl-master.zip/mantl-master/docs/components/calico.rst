.. include:: ../../roles/calico/README.rst
