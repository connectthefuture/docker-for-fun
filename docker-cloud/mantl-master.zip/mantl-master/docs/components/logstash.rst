.. include:: ../../roles/logstash/README.rst
