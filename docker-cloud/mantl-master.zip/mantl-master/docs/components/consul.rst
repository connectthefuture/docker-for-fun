.. include:: ../../roles/consul/README.rst
