.. include:: ../../roles/logrotate/README.rst
