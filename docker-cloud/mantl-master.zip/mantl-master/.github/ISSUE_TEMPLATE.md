Hi! We'd love to help you with whatever problem you're having with Mantl. To
help us, please provide the following along with a description of your issue.
You can delete this message once you're done. Thanks!

- Ansible version (`ansible --version`): 
- Python version (`python --version`):
- Git commit hash or branch: 
- Cloud Environment: 
- Terraform version (`terraform version`):
