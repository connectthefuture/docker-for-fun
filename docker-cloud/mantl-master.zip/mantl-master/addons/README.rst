Addons
======

Addons are Ansible roles or other software configurations that have been known
to work well with Mantl. These are not as tested and maintained as the core
components (those listed in the sample playbook), so please allow for some
manual configuration.

All addon playbooks should be run after the initial installation of Mantl via
the sample playbook. Documentation on their installation and customization is
provided in their component READMEs.
