## Components

Apollo is made up of a number of other open-source components. If you want more details on an individual component and the reasons behind utilising it see the below section.

- **[Ansible](ansible.md)**
- **[Apache Mesos](apache-mesos.md)**
- **[Consul](consul.md)**
- **[Docker](docker.md)**
- **[Terraform](terraform.md)**
- **[Vault](vault.md)**
- **[Weave](weave.md)**
